"""Regression from a real clipped AV-WIDE branch with an unsampled tail."""
import unittest
import numpy as np
from scipy.interpolate import BSpline
from native2d.targets import fit_controls
from metrics.representation_geometry import point_to_polyline_distance

class StableSplineTargetTests(unittest.TestCase):
    def test_uneven_dense_path_retains_geometry(self):
        path=np.array([[103,90],[100,88],[96,85],[91,83],[88,82],[83,79],
            [79,77],[76,75],[72,73],[69,72],[66,70],[63,68],[60,68],
            [57,68],[54,66],[19.125,61.125]],float)
        controls=fit_controls(path)
        knots=np.r_[np.zeros(4),np.arange(1,5)/5,np.ones(4)]
        curve=BSpline(knots,controls,3)(np.linspace(0,1,257))
        np.testing.assert_array_equal(controls[[0,-1]],path[[0,-1]])
        self.assertLess(float(np.abs(controls).max()),200.)
        self.assertLess(float(point_to_polyline_distance(curve,path).max()),3.)

if __name__=='__main__':unittest.main()
