#!/usr/bin/env python3
"""Collect measured outcomes without inference, retries or new GPU submission."""
import fcntl
import hashlib
import json
import subprocess
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'experiments/native2d_20261028'
MAIN=ROOT.parent/'Graph-Native-Betti-Matching-Representation'
START='<!-- NATIVE2D HELDOUT LIVE 20261028 -->'
END='<!-- END NATIVE2D HELDOUT LIVE 20261028 -->'

def read(path):
    return json.loads(path.read_text()) if path.exists() else None

def update(path,body):
    with Path(str(path)+'.native2d.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        text=path.read_text() if path.exists() else ''
        block=START+'\n'+body+'\n'+END
        if START in text:
            a,b=text.split(START,1);_,c=b.split(END,1);text=a+block+c
        else:text=text.rstrip()+'\n\n'+block+'\n'
        path.write_text(text)

def main():
    gate=read(OUT/'gates.json');audit=read(OUT/'av-wide-audit.json');submission=read(OUT/'submission.json')
    record=dict(gates=gate,audit=audit,submission=submission,arms={})
    body=['## Native2D-02: held-out original-width AV-WIDE study — 28 October 2026','',
        'Authorized bounded B0 versus A-xyz pilot, following Native2D-01. All measurements below refer to image-disjoint validation, never test data. Patient independence is unverified. Distances are pixels.', '']
    if audit:body.append(f"Cohort: 17 train / 6 validation images; six reserved test images have header-only inspection. Image07 excluded for its diagonal self-loop. {audit['samples']['train']} train / {audit['samples']['validation']} validation 128² tiles; {audit['queries']} object queries selected from contracted training GT. All spatial tiles retained, including empty graphs.")
    if gate:
        body.append(f"Full ResNet101/512D, 3 encoder + 3 decoder layers, 5 relation tokens: gates {'PASSED' if gate['passed'] else 'FAILED'}; {gate['full_architecture_optimizer_updates']} optimizer updates on two 128² training tiles before the experiment. Shared initialization and graph-only gradient checks passed. Budget fixed to {gate['updates']} updates per arm, batch4, no automatic extension.")
        body.append('Throughput (existing PyTorch deformable attention): '+', '.join(f"{r['arm']} {r['seconds_per_update']:.4f}s/update, {r['images_per_second']:.2f} images/s" for r in gate['benchmark'])+'.')
    if submission:body.append('Slurm: '+', '.join(f'{k} `{v}`' for k,v in submission.items() if isinstance(v,str) and v.isdigit())+'.')
    body.extend(['','| Arm | State | Selected update | Node F1 @2px | Edge F1 @2px | Branch F1 @1px | K8 Curve F1 @1px | Chord Curve F1 @1px |',
        '|---|---|---:|---:|---:|---:|---:|---:|'])
    fig,axes=plt.subplots(1,3,figsize=(13,3.5))
    for arm in ['B0','Axyz']:
        directory=OUT/arm;status=read(directory/'status.json');held=read(directory/'best-heldout.json');failure=read(OUT/(arm+'-failure.json'))
        curve=read(directory/'learning-curve.json') or []
        record['arms'][arm]=dict(status=status,selected_heldout=held,failure=failure)
        state='complete' if held else ('failed' if failure else (status or {}).get('state','not started'))
        if held:
            s=held['summary'];body.append(f"| {arm} | {state} | {held['step']} | {s['2.0']['node']['f1']:.4f} | {s['2.0']['edge']['f1']:.4f} | {s['spline']['common_branch_f1']:.4f} | {s['spline']['common_curve_f1']:.4f} | {s['chord']['common_curve_f1']:.4f} |")
        else:body.append(f'| {arm} | {state} | — | — | — | — | — | — |')
        if curve:
            for ax,kind in zip(axes[:2],['node','edge']):
                ax.plot([r['step'] for r in curve],[r['validation']['2.0'][kind]['f1'] for r in curve],marker='o',label=arm)
                ax.set_ylabel(kind+' micro F1 @2px')
            train=[]
            if (directory/'training.jsonl').exists():
                train=[json.loads(line) for line in (directory/'training.jsonl').read_text().splitlines()]
            if train:axes[2].plot([r['step'] for r in train],[r['losses']['total'] for r in train],label=arm)
    for ax in axes:
        ax.set_xlabel('optimizer update');ax.grid(alpha=.25)
        if ax.lines:ax.legend()
    axes[2].set_ylabel('training total loss');fig.tight_layout();fig.savefig(OUT/'learning-curves.png',dpi=150);plt.close(fig)
    body.extend(['','Intermediate validation uses 24 fixed spatial tiles (4/image); final and selected checkpoints are evaluated on every validation tile. Curve points at final therefore use a larger population; do not interpret that discontinuity as a training change. Selection uses the same 24 tiles throughout. Best and final outcomes are both saved.',
        '', 'Detection AP/AR uses unthresholded query scores, IoU .50:.05:.95, node limit equal to query capacity and edge top300; reported AP is crop macro. Physical node/edge F1 is micro over crops at 1/2/4px, including crop-boundary anchors. Branch/Curve F1 is crop macro at 1px, .25px sampling. Spline/chord use identical inferred nodes/edges; topology cannot change. Raw/filtered recall, relation AP populations, duplicates and Betti errors are retained per crop. No subject-level uncertainty claim, full-image stitching, independent manual topology or pretraining benefit is established.',
        '', f'Evidence and checkpoints: `{OUT}`. [Protocol and dataset readiness](../docs/research/native2d_heldout_20261028.md). Learning curves: `learning-curves.png`; full metrics: `B0/best-heldout.json`, `Axyz/best-heldout.json`; final metrics: `<arm>/validation-<budget>.json`; weights/optimizer: `<arm>/best.pt`, `<arm>/latest.pt`. Failed gates and jobs are reported without automatic resubmission.'])
    text='\n\n'.join(body[:0])+ '\n'.join(body)
    (OUT/'report.md').write_text(text+'\n')
    (OUT/'results.json').write_text(json.dumps(record,indent=2,allow_nan=True)+'\n')
    for path in [MAIN/'research/VASCULAR_GRAPH_EXPERIMENT_REGISTRY_2026-10-26_UPDATED.md',MAIN/'research/image-to-graph-vessel.md',MAIN/'research/experiments.md']:
        update(path,text)
    hashes=[]
    for arm in ['B0','Axyz']:
        s=read(OUT/arm/'status.json')
        if s:hashes.append((s['exposure_sha256'],s['initialization_sha256']))
    assert len(set(hashes))<=1,'Paired initialization/exposure mismatch'
    coord=ROOT.parent/'experiment_gpu_coordination/native2d-20261028.json'
    claim=read(coord)
    if claim:
        complete=all(record['arms'][a]['selected_heldout'] is not None for a in ['B0','Axyz'])
        claim.update(state='completed held-out pilot' if complete else 'collected; inspect gates and arm status',
            concurrent_h100=0,reserved_after_dependency=0,completed=complete)
        coord.write_text(json.dumps(claim,indent=2)+'\n')
    print(text)

if __name__=='__main__':main()
