"""Read study artifacts with stdlib only, from any current directory."""
import json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
meta=root/'experiments/ixi_local_components_20261026'
p=json.loads((meta/'plan.json').read_text());output=Path(p['output_root'])
print('Outputs:',output)
if (meta/'jobs.json').exists():print((meta/'jobs.json').read_text())
if (output/'results.md').exists():print((output/'results.md').read_text())
else:
 for path in [output/'smoke.json']+sorted(output.glob('runs/*/progress.json'))+sorted(output.glob('runs/*/complete.json')):
  print(path.relative_to(output),path.read_text())
 print('Results are not collected yet. This command performs no inference or training.')
