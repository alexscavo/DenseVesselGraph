# ------------------------------------------------------------------------------------------------
# Deformable DETR
# Copyright (c) 2020 SenseTime. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------------------------------
# Modified from https://github.com/chengdazhi/Deformable-Convolution-V2-PyTorch/tree/pytorch_1.0.0
# ------------------------------------------------------------------------------------------------

from __future__ import absolute_import
from __future__ import print_function
from __future__ import division

import torch
import torch.nn.functional as F
from torch.autograd import Function
from torch.autograd.function import once_differentiable

try:
    import MultiScaleDeformableAttention3D as MSDA3D
except ImportError:
    MSDA3D = None


def cuda_extension_available():
    """Return whether the compiled 3D deformable-attention extension imports."""

    return MSDA3D is not None


class MSDeformAttnFunction(Function):
    @staticmethod
    def forward(ctx, value, value_spatial_shapes, value_level_start_index, sampling_locations, attention_weights, im2col_step):
        if MSDA3D is None:
            raise RuntimeError(
                "MultiScaleDeformableAttention3D is not installed. Build "
                "models/ops or configure model.decoder.use_cuda_extension=false."
            )
        ctx.im2col_step = im2col_step
        output = MSDA3D.ms_deform_attn_forward(
            value, value_spatial_shapes, value_level_start_index, sampling_locations, attention_weights, ctx.im2col_step)
        ctx.save_for_backward(value, value_spatial_shapes, value_level_start_index, sampling_locations, attention_weights)
        return output

    @staticmethod
    @once_differentiable
    def backward(ctx, grad_output):
        value, value_spatial_shapes, value_level_start_index, sampling_locations, attention_weights = ctx.saved_tensors
        grad_value, grad_sampling_loc, grad_attn_weight = \
            MSDA3D.ms_deform_attn_backward(
                value, value_spatial_shapes, value_level_start_index, sampling_locations, attention_weights, grad_output, ctx.im2col_step)

        return grad_value, None, None, grad_sampling_loc, grad_attn_weight, None


def ms_deform_attn_core_pytorch(value, value_spatial_shapes, sampling_locations, attention_weights):
    # for debug and test only,
    # need to use cuda version instead

    N_, S_, M_, D_ = value.shape
    _, Lq_, M_, L_, P_, _ = sampling_locations.shape

    # Split projection of input features back into individual levels
    level_sizes = [
        int(depth * height * width)
        for depth, height, width in value_spatial_shapes.tolist()
    ]
    value_list = value.split(level_sizes, dim=1)

    sampling_grids = 2 * sampling_locations - 1     # To get in range of [-1, 1], as necessary for F.grid_sample 
    sampling_value_list = []
    for lid_, (D, H, W) in enumerate(value_spatial_shapes):
        value_l_ = value_list[lid_].flatten(2).transpose(1, 2).reshape(N_*M_, D_, D, H, W)                          # [Batch*NumHeads, FeatureDim, D, H, W]
        sampling_grid_l_ = sampling_grids[:, :, :, lid_].transpose(1, 2).flatten(0, 1)                              # [Batch*NumHeads, AllLvlPatches, NumPoints, Offset]

        # value_l_ in format DHW, sampling_grid_l_ in format WHD/XYZ (see F.grid_sample doc)
        sampling_value_l_ = F.grid_sample(
            value_l_, sampling_grid_l_[:, None], mode='bilinear', padding_mode='zeros', align_corners=False         # [Batch*NumHeads, FeatureDim, AllLvlPatches, NumPoints]
        ).squeeze(2)    # TODO: check this hack
        sampling_value_list.append(sampling_value_l_)

    attention_weights = attention_weights.transpose(1, 2).reshape(N_*M_, 1, Lq_, L_*P_)
    output = (torch.stack(sampling_value_list, dim=-2).flatten(-2) * attention_weights).sum(-1).view(N_, M_*D_, Lq_)
    return output.transpose(1, 2).contiguous()


__all__ = [
    "MSDeformAttnFunction",
    "cuda_extension_available",
    "ms_deform_attn_core_pytorch",
]
